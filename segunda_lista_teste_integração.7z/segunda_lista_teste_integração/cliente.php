<?php

    include 'conecta.php';

    class Cliente{

        public $nome;
        public $email;
        public $telefone;
        public $cpf;
        public $data_nasc;
        public $cep;

        public function cadastroCliente($nome, $email, $telefone, $cpf, $data_nasc, $cep){
            $query = "INSERT INTO cadastro(nome,email,telefone,cpf,data_nascimento,cep) values('".$nome."','".$email."','".$telefone."','".$cpf."','".$data_nasc."','".$cep."'";
            mysqli_query($conn,$query);
        }

    }

?>