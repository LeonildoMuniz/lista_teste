<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/style.css">
    <title>Cadastro de Clientes</title>
</head>
<body>
    <form action="" method="post">
        <div id="container">
            <h1 class="clienteText">Casdastro de Clientes</h1>
            <div class="containerInput">
                <input type="text" name="nome" id="nome" placeholder="Digite o nome!" require>
                <input type="email" name="email" id="email" placeholder="Digite o email!" require>
                <input type="tel" name="telefone" id="telefone" placeholder="Digite o telefone!" require>
                <input type="text" name="cpf" id="cpf" placeholder="Digite o CPF!">
                <input type="date" name="data" id="data" placeholder="Digite a data de nascimento!">
                <input type="text" name="cep" id="cep" placeholder="Digite o CEP!">
                <button type="submit">Cadastrar</button>
            </div>
        </div>
    </form>
</body>
</html>